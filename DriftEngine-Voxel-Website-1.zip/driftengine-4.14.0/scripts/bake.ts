/**
 * `drft bake` — turn a model, or a bought bundle, into a `.drft`.
 *
 *   npx tsx scripts/bake.ts model.glb -o model.drft
 *   npx tsx scripts/bake.ts ./tomb-props -o tomb-props.drft
 *   npx tsx scripts/bake.ts ./tomb-props --from obj
 *
 * **A bought asset is a bundle, not a file.** A download is typically the source the
 * artist worked in plus conversions — glb, gltf, obj, fbx, usdz — every one of them the
 * same model, exactly one of them the best thing to read. So a directory is a valid input
 * and the tool inventories it, picks the highest tier present, and *prints what it chose
 * and what it passed over*. Choosing in silence would be the worst outcome available: an
 * experimental reader used while a conformance-tested file sat in the next folder, with
 * nobody able to notice.
 *
 * Offline, in Node. No third-party format is ever parsed at runtime, so a reader meeting
 * a file it does not understand costs a failed bake rather than a broken frame.
 *
 * **The bake itself is `bakeModel` in `@driftengine/assets`**: everything between reading a model and
 * writing a container, so a test bakes the way this command does. What stays here is what needs a
 * disk or a flag parser: choosing the file in a bundle, finding a named picture beside it, sibling
 * levels and collision files, and the file written. A `.glb` that `drft export` wrote bakes back to
 * the container it came from, with what glTF has no field for read from the records it left.
 */

import { readFileSync, statSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { MODEL_FORMATS, bakeModel, readModel, readerFor } from '@driftengine/assets';
import type { BakeModelOptions, ModelImport } from '@driftengine/assets';
import { describeRecognised, recognise } from '@driftengine/assets';
import { gunzipSync, inflateRawSync, inflateSync, zstdDecompressSync } from 'node:zlib';
import { BlendNeedsBlender } from '@driftengine/assets';
import { exportWithBlender, findBlender } from './blenderHost.ts';
import { writeDrft } from '@driftengine/drft';
import { dropDefaultAttributes, weldMesh } from '@driftengine/assets';
import { withTangentsIfMapped } from '@driftengine/assets';
import { orientMeshes, orientNodes, parseUpAxis } from '@driftengine/assets';
import type { UpAxis } from '@driftengine/assets';
import { DrftError, codecName } from '@driftengine/drft';
import { MAX_COLLIDER_HULLS } from '@driftengine/drft';
import { decomposeConvex } from '@driftengine/physics';
import { readFile } from 'node:fs/promises';
import type { DrftMaterial } from '@driftengine/drft';
import type { DrftTextureSource } from '@driftengine/drft';
import { assetCandidates, identifyTexture, placeholderTexture } from '@driftengine/assets';
import type { AssetReference } from '@driftengine/assets';
import { isDds } from '@driftengine/assets';
import { describeDropped, reachableTextures } from '@driftengine/assets';
/* The Node-side PNG encoder, which is why a decoded surface is not embedded uncompressed. */
import { processTextures } from './bakeTextureCap.ts';
import { ddsTexture } from './bakeDds.ts';
import { colliderBeside, levelsBeside } from '@driftengine/assets';
import type { MeshData } from '@driftengine/drft';

/**
 * The reader table and the dispatch both live in `packages/assets/src/readModel.ts` now.
 *
 * They were here, and they were written against Node: `readFileSync` for a `.gltf`'s external
 * buffers and for an `.obj`'s `.mtl`, `node:zlib` for the two compressed containers. None of
 * that is about *which reader a file needs*, so a browser wanting the same answer would have
 * had to copy the dispatch and keep the copy in step with every format added after it. The
 * dispatch moved; the IO below stayed here, which is where it belongs.
 */
const READERS = MODEL_FORMATS;

/** Every file under a directory, so a bundle's nested `gltf/` and `source/` are both seen. */
function walk(dir: string, depth = 0): string[] {
  if (depth > 4) return [];
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full, depth + 1));
    else out.push(full);
  }
  return out;
}

/**
 * Node's side of a read: the filesystem and zlib, handed to the shared dispatcher.
 *
 * `beside` resolves against the model's own directory, which is what a `.gltf` and an
 * `.obj` mean by a relative name. The two inflates are different functions on purpose: a
 * zip stores a bare deflate stream and FBX embeds a zlib-wrapped one.
 */
function loadModel(
  file: string,
  bytes: Uint8Array = readFileSync(file),
  name = path.basename(file),
): Promise<ModelImport> {
  return readModel({
    name,
    bytes,
    beside: (relative) => {
      try {
        return Promise.resolve(
          new Uint8Array(readFileSync(path.join(path.dirname(file), relative))),
        );
      } catch {
        return Promise.resolve(null);
      }
    },
    /*
     * The frame is derived after the weld, below, and not here. The derivation accumulates per
     * index, so on a file storing one vertex per triangle corner it gives every corner its own
     * frame and the weld can merge none of them: 9,600 corners to 9,482 vertices instead of 1,681,
     * measured in `tangentOrder.test.ts`. Deriving on the merged mesh is a smaller file and a
     * better frame, since sharing is what the derivation averages over.
     */
    deriveTangents: false,
    inflate: (data, expected) =>
      new Uint8Array(inflateSync(data, { maxOutputLength: Math.max(expected, 1) * 2 })),
    inflateRaw: (data, expected) =>
      new Uint8Array(inflateRawSync(data, { maxOutputLength: Math.max(expected, 1) * 2 })),
    decompress: (data, codec) =>
      new Uint8Array(codec === 'zstd' ? zstdDecompressSync(data) : gunzipSync(data)),
  });
}

/**
 * A `.blend`, read directly where the reader can and through the person's Blender where it cannot.
 *
 * **The order is the one docs/FORMAT.md §3.2 promises**: the direct reader first, because it needs
 * nothing installed and gives the same bytes on every machine, and Blender when the file holds
 * something only Blender can evaluate — a modifier, a constraint, a rig — or a node graph the direct
 * reader can only approximate and Blender's exporter knows more of. `--via-blender` asks for
 * Blender outright and `--direct` refuses it. Every route says which it took.
 */
async function loadBlend(
  file: string,
  args: readonly string[],
  workIn: string,
): Promise<ModelImport> {
  const direct = args.includes('--direct');
  const viaBlender = args.includes('--via-blender');
  let reason: readonly string[] = [];
  if (!viaBlender) {
    try {
      const read = await loadModel(file);
      const approximations = read.approximations ?? [];
      if (approximations.length === 0 || direct) {
        console.log(`${path.basename(file)} — read directly (tier 2)`);
        return read;
      }
      reason = approximations;
      if (findBlender() === null) {
        console.log(
          `${path.basename(file)} — read directly; Blender is not installed, so ${approximations.length} approximations stand`,
        );
        return read;
      }
    } catch (error) {
      if (!(error instanceof BlendNeedsBlender) || direct) throw error;
      reason = error.reasons;
    }
  }
  const blender = findBlender();
  if (blender === null) {
    console.error(
      `${path.basename(file)} needs Blender, and none was found. Install it, put \`blender\` on the ` +
        'path, or set BLENDER to its executable. The direct reader said:',
    );
    for (const line of reason) console.error(`  ${line}`);
    process.exit(1);
  }
  console.log(
    `${path.basename(file)} — exported by ${blender.version}${viaBlender ? ' (--via-blender)' : ', because:'}`,
  );
  for (const line of reason.slice(0, 12)) console.log(`  ${line}`);
  if (reason.length > 12) console.log(`  …and ${reason.length - 12} more`);
  const { glb, log } = exportWithBlender(blender, file, workIn);
  for (const line of log) console.log(`  ${line}`);
  return loadModel(file, glb, `${path.basename(file, path.extname(file))}.glb`);
}

/**
 * An image, identified and wrapped for embedding: a DDS through `bakeDds.ts`, anything else by its
 * own header.
 *
 * **Every texture comes through here, whoever found its bytes.** The reader resolves the images a
 * model names beside the model, and a glTF carries its own as often as it points at files; the
 * baker's own search of the folder it was given finds the rest. That search had a copy of this
 * that knew PNG, JPEG and WEBP only, so a DDS it found baked as a white pixel while the same bytes
 * beside the model were decoded. The bytes are identified rather than trusted: glTF's `mimeType` is
 * optional and wrong often enough that the image's own header is the only reliable answer.
 */
function describeTexture(
  name: string,
  bytes: Uint8Array,
  decodeDds: boolean,
  warnings: string[],
): DrftTextureSource {
  if (isDds(bytes)) return ddsTexture(name, bytes, decodeDds, warnings);
  const texture = identifyTexture(name, bytes, warnings);
  if (texture.bytes === bytes) {
    console.log(
      `  texture ${name} — ${codecName(texture.codec)} ${texture.width}x${texture.height}, ` +
        `${(bytes.length / 1024).toFixed(0)} KB embedded`,
    );
  }
  return texture;
}

/**
 * Find the images a model named, and embed them.
 *
 * The engine says what to look for and this says where to look, which is the split the
 * whole of `assetPath.ts` exists for: only the host knows it is reading a folder on a disk.
 *
 * A texture that cannot be found is a **warning and not a refusal**, and that is a departure
 * from the tier 2 rule that a reader refuses rather than half-imports. The reason is that
 * this failure is not ambiguous the way a half-read mesh is: the geometry, the UVs and the
 * material colours are all completely read, the model draws correctly, and the only thing
 * missing is named on screen. Refusing the whole bake because one map was left out of a
 * download would make a 50 MB asset unusable over a file the artist may never have shipped.
 */
function embedTextures(
  refs: readonly AssetReference[],
  modelFile: string,
  searchRoot: string,
  decodeDds: boolean,
  warnings: string[],
): DrftTextureSource[] {
  const out: DrftTextureSource[] = [];
  const roots = [path.dirname(modelFile), searchRoot];
  for (const reference of refs) {
    const declared = reference.name;
    /* Already in hand: a glTF image inside the binary chunk or a data URI needs no lookup. */
    if (reference.bytes !== undefined) {
      out.push(describeTexture(declared, reference.bytes, decodeDds, warnings));
      continue;
    }
    let found: { file: string; bytes: Uint8Array } | null = null;
    for (const root of roots) {
      for (const candidate of assetCandidates(declared)) {
        const full = path.join(root, candidate);
        try {
          if (!statSync(full).isFile()) continue;
          found = { file: full, bytes: new Uint8Array(readFileSync(full)) };
          break;
        } catch {
          /* Not there. The next candidate is the point of having candidates. */
        }
      }
      if (found !== null) break;
    }

    if (found === null) {
      warnings.push(
        `texture "${declared}" was not found beside the model; it will draw untextured`,
      );
      /* A placeholder keeps every material's index meaning what it meant. */
      out.push(placeholderTexture(declared));
      continue;
    }

    console.log(`  texture "${declared}" found at ${path.relative(searchRoot, found.file)}`);
    out.push(describeTexture(declared, found.bytes, decodeDds, warnings));
  }
  return out;
}

/** What `--collider` asked for. `none` is the default and writes no chunk at all. */
type ColliderMode = { kind: 'none' } | { kind: 'box' } | { kind: 'hull'; maxHulls: number };

/**
 * `--collider none | box | hull | hull:N`.
 *
 * **`none` by default**, because collision is not something a bake should invent: an asset that
 * carries hulls it was never asked for is bytes every consumer pays for and a shape somebody has to
 * discover is wrong. Asking for it is one flag.
 */
function colliderFlag(args: readonly string[]): ColliderMode {
  const at = args.indexOf('--collider');
  if (at === -1) return { kind: 'none' };
  const value = args[at + 1];
  if (value === undefined || value.startsWith('--')) {
    throw new Error('--collider takes none, box, hull, or hull:N');
  }
  if (value === 'none') return { kind: 'none' };
  if (value === 'box') return { kind: 'box' };
  if (value === 'hull') return { kind: 'hull', maxHulls: 16 };
  const match = /^hull:(\d+)$/.exec(value);
  if (match === null) throw new Error(`--collider ${value} is not none, box, hull, or hull:N`);
  const maxHulls = Number(match[1]);
  if (!(maxHulls >= 1 && maxHulls <= MAX_COLLIDER_HULLS)) {
    throw new Error(`--collider hull:${maxHulls} is outside 1 to ${MAX_COLLIDER_HULLS}`);
  }
  return { kind: 'hull', maxHulls };
}

/** Every mesh's positions, end to end, as one array for the decomposition to rasterise. */
function collisionPositions(meshes: readonly { positions: Float32Array }[]): Float32Array {
  let total = 0;
  for (const mesh of meshes) total += mesh.positions.length;
  const out = new Float32Array(total);
  let at = 0;
  for (const mesh of meshes) {
    out.set(mesh.positions, at);
    at += mesh.positions.length;
  }
  return out;
}

/** The same for indices, with each mesh's shifted past the vertices before it. */
function collisionIndices(
  meshes: readonly { positions: Float32Array; indices: Uint32Array }[],
): Uint32Array {
  let total = 0;
  for (const mesh of meshes) total += mesh.indices.length;
  const out = new Uint32Array(total);
  let at = 0;
  let base = 0;
  for (const mesh of meshes) {
    for (let i = 0; i < mesh.indices.length; i++) out[at + i] = (mesh.indices[i] as number) + base;
    at += mesh.indices.length;
    base += mesh.positions.length / 3;
  }
  return out;
}

/** The eight corners of a point cloud's bounds, which is the cheapest honest collider there is. */
function boundsHull(positions: Float32Array): Float32Array {
  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let maxZ = -Infinity;
  for (let i = 0; i + 2 < positions.length; i += 3) {
    minX = Math.min(minX, positions[i] as number);
    maxX = Math.max(maxX, positions[i] as number);
    minY = Math.min(minY, positions[i + 1] as number);
    maxY = Math.max(maxY, positions[i + 1] as number);
    minZ = Math.min(minZ, positions[i + 2] as number);
    maxZ = Math.max(maxZ, positions[i + 2] as number);
  }
  const out = new Float32Array(24);
  for (let i = 0; i < 8; i++) {
    out[i * 3] = i & 1 ? maxX : minX;
    out[i * 3 + 1] = i & 2 ? maxY : minY;
    out[i * 3 + 2] = i & 4 ? maxZ : minZ;
  }
  return out;
}

/** What `textured` in `main` does: the flags' processing over embedded pictures. */
type Textured = (
  textures: DrftTextureSource[],
  materials: readonly DrftMaterial[] | undefined,
  warnings: string[],
) => Promise<DrftTextureSource[]>;

/**
 * Discrete levels of detail, where a bundle ships them as sibling files.
 *
 * **Each is baked whole and nested, not merged into `LODM`.** A hand-authored level is a complete
 * model with its own materials and hierarchy; `LODM` holds one merged, material-less outline for a
 * progressive load. Folding one into the other would discard every material the level carries,
 * which is the opposite of why a source ships four of them.
 */
async function bakeLevels(
  chosen: string,
  siblings: readonly string[],
  args: readonly string[],
  up: UpAxis | null,
  quantise: boolean,
  decodeDds: boolean,
  textured: Textured,
): Promise<Uint8Array[]> {
  const levelFiles = args.includes('--no-levels')
    ? []
    : levelsBeside(path.basename(chosen), siblings);
  const levels: Uint8Array[] = [];
  /* Collected and not printed, as they always were: a level's missing picture is the model's. */
  const warnings: string[] = [];
  for (const name of levelFiles) {
    const full = path.join(path.dirname(chosen), name);
    const level = await loadModel(full);
    /* The same order as level 0: weld, then derive for the materials that sample one. */
    const levelMeshes = level.meshes.map((mesh, at) =>
      dropDefaultAttributes(withTangentsIfMapped(weldMesh(mesh), level.materials?.[at])),
    );
    const oriented = up === null || up === '+y' ? levelMeshes : orientMeshes(levelMeshes, up);
    /*
     * A level carries its own textures, and it has to: `DrftMaterial.albedo` is an ordinal into
     * the asset's own texture list, so a nested file whose materials point at level 0's images is
     * not a valid asset and `readDrft` refuses it — correctly. That is what makes a level
     * independently openable, and it is the cost `--no-levels` exists to decline.
     */
    const levelReached = reachableTextures(level.textures ?? [], level.materials);
    const dropped = describeDropped(levelReached.dropped);
    if (dropped !== null) console.log(dropped);
    const levelTextures = await textured(
      levelReached.refs.length === 0
        ? []
        : embedTextures(levelReached.refs, full, path.dirname(full), decodeDds, warnings),
      levelReached.materials,
      warnings,
    );
    levels.push(
      new Uint8Array(
        writeDrft({
          meshes: oriented,
          quantise,
          head: { name: path.basename(name, path.extname(name)), generator: 'drft bake' },
          ...(levelTextures.length === 0 ? {} : { textures: levelTextures }),
          ...(levelReached.materials === undefined
            ? {}
            : { materials: [...levelReached.materials] }),
          ...(level.nodes === undefined || level.nodes.length === 0
            ? {}
            : { nodes: up === null ? level.nodes : orientNodes(level.nodes, up) }),
        }),
      ),
    );
    console.log(
      `  level ${levels.length}: ${name}, ${oriented.length} meshes, ` +
        `${level.materials?.length ?? 0} materials, ${((levels[levels.length - 1]?.length ?? 0) / 1024 / 1024).toFixed(1)} MB`,
    );
  }
  return levels;
}

/**
 * **`--collider` decides what the file collides as, and `none` is the default**, which leaves any
 * colliders a `.drft` export carried to stand.
 *
 * `box` is the asset's own bounds as one hull, which costs nothing and is what a great many props
 * actually want. `hull[:N]` decomposes the geometry with `decomposeConvex`, at most N parts.
 *
 * **A vehicle folder's `collider.kn5` is preferred over the model's own geometry**, and that is
 * the whole point of finding it: an artist who shipped a collision mesh meant that mesh to be the
 * collision, and it is a fraction of the triangles.
 */
async function bakeColliders(
  mode: ColliderMode,
  chosen: string,
  siblings: readonly string[],
  meshes: readonly MeshData[],
  up: UpAxis | null,
): Promise<Float32Array[] | undefined> {
  if (mode.kind === 'none') {
    const beside = colliderBeside(siblings);
    if (beside !== null) {
      console.log(`  collider: ${beside} found and not baked — pass --collider hull to carry it`);
    }
    return undefined;
  }
  const hull = colliderBeside(siblings);
  let source = { positions: collisionPositions(meshes), indices: collisionIndices(meshes) };
  if (hull !== null) {
    const beside = await readModel({
      name: hull,
      bytes: new Uint8Array(await readFile(path.join(path.dirname(chosen), hull))),
    });
    const besideMeshes = up === null ? beside.meshes : orientMeshes(beside.meshes, up);
    source = {
      positions: collisionPositions(besideMeshes),
      indices: collisionIndices(besideMeshes),
    };
    console.log(`  collider: ${hull}, ${besideMeshes.length} meshes — baked into this file`);
  }
  if (mode.kind === 'box') {
    console.log('  collider: the asset bounds, as one hull');
    return [boundsHull(source.positions)];
  }
  const decomposed = decomposeConvex(source.positions, source.indices, {
    maxHulls: mode.maxHulls,
  });
  const colliders = decomposed.parts.map((part) => part.points);
  console.log(
    `  collider: ${colliders.length} hulls, ` +
      `${(decomposed.bloat * 100).toFixed(1)}% over the source by volume, ` +
      `${(decomposed.coverage * 100).toFixed(1)}% of it covered`,
  );
  return colliders;
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const input = args[0];
  if (input === undefined || input.startsWith('-')) {
    console.error(
      'usage: bake <file-or-folder> [-o out.drft] [--from glb|gltf|obj|stl] [--up x|-x|y|-y|z|-z]' +
        ' [--lod cells] [--no-lod] [--no-levels] [--max-texture px] [--texture-codec jpeg|jpeg-all] [--sdf m]' +
        ' [--normals-directx] [--decode-dds] [--simplify m]' +
        ' [--no-instances] [--no-quantise] [--blend-as-cutout] [--direct | --via-blender]',
    );
    process.exit(1);
  }
  const outIndex = args.indexOf('-o');
  const fromIndex = args.indexOf('--from');
  const forced = fromIndex === -1 ? null : (args[fromIndex + 1] ?? null);
  /*
   * Which way is up in the asset, when the asset itself is not to be believed.
   *
   * Deliberately not guessed. A model can be measured for which of its axes looks most like
   * "up" — the tallest extent, the widest base — and every such rule is wrong on something
   * ordinary: a wheel is symmetrical, a plank is not upright, a car is wider at the bottom
   * until it is a van. Guessing also fails silently, which is the expensive part, so this is
   * told rather than inferred and the line below records what it was told.
   */
  const upIndex = args.indexOf('--up');
  const assetUp = upIndex === -1 ? null : parseUpAxis(args[upIndex + 1] ?? '');

  /*
   * The coarse outline, **written unless `--no-lod` refuses it**, at `--lod cells` for a
   * resolution other than the default.
   *
   * It was off unless asked for, on the argument that whether a coarse level of *this* asset is
   * worth looking at cannot be measured here: detail living well below the grid decimated into
   * lumps and ridges, and a viewer waiting for a car saw white cliffs, which is worse than an
   * empty scene because an empty scene reads as a load and a bad preview reads as a broken
   * import. That argument was about the clustering hull. The occupancy hull emits the boundary
   * of a solid, so the worst case is a coarse version of the shape rather than a shape that was
   * never there, and the cost is 150 KB of a 76 MB car and about 640 ms of a bake.
   *
   * `--no-lod` still refuses, and it is the flag to reach for on anything where the printed
   * triangle count comes out absurd for the model.
   */
  const lodIndex = args.indexOf('--lod');
  /*
   * A token beginning with `-` is the next flag, not a cell count.
   *
   * Reported from outside: `--lod -o out.drft` refused with `--lod wants a number of cells, got
   * "-o"`, so `--lod` silently had to be last. The message was right about what it read and gave
   * no hint that the position was the problem.
   */
  const lodArg = args[lodIndex + 1];
  const lodNamed = lodArg !== undefined && !lodArg.startsWith('-');
  /* `null` refuses, a number asks, and absent leaves it to `bakeModel`: a carried outline, or the
     default resolution. */
  const lodCells = args.includes('--no-lod')
    ? null
    : lodIndex === -1 || !lodNamed
      ? undefined
      : Number(lodArg);
  if (typeof lodCells === 'number' && !Number.isFinite(lodCells)) {
    console.error(`--lod wants a number of cells, got "${lodArg ?? ''}"`);
    process.exit(1);
  }

  /*
   * `--max-texture px`: no image's longer side over `px`, halved until it fits. Absent means no
   * cap, which is every bake before the flag existed, and those keep their bytes exactly.
   */
  const capIndex = args.indexOf('--max-texture');
  const capArg = capIndex === -1 ? undefined : args[capIndex + 1];
  const maxTexture = capArg === undefined ? undefined : Number(capArg);
  if (
    capIndex !== -1 &&
    (maxTexture === undefined || !Number.isInteger(maxTexture) || maxTexture < 1)
  ) {
    console.error(`--max-texture wants a whole number of texels, got "${capArg ?? ''}"`);
    process.exit(1);
  }

  /* Choosing the file, which for a bundle is the whole job. */
  let chosen: string;
  const stat = statSync(input);
  if (stat.isDirectory()) {
    const candidates = walk(input)
      .map((file) => ({ file, reader: readerFor(path.extname(file)) }))
      .filter(
        (entry): entry is { file: string; reader: (typeof READERS)[number] } =>
          entry.reader !== undefined,
      );
    if (candidates.length === 0) {
      console.error(
        `${input} — nothing readable here. Looked for: ${READERS.map((r) => r.ext).join(', ')}`,
      );
      /*
       * Before the generic advice, say something specific about what *is* in the folder.
       * A bundle whose only model is a Maya binary should be told which export works,
       * rather than being handed a list of extensions it does not contain.
       */
      let named = false;
      for (const file of walk(input)) {
        let head: Uint8Array;
        try {
          head = readFileSync(file);
        } catch {
          continue;
        }
        const foreign = recognise(head);
        if (foreign === null) continue;
        console.error(describeRecognised(foreign, path.basename(file)));
        named = true;
      }
      if (!named) console.error('If this bundle has an .ma only, export glTF from it for now.');
      process.exit(1);
    }
    const found = [...new Set(candidates.map((c) => c.reader.ext.slice(1)))];
    console.log(`${input} — found ${found.join(', ')}`);

    const wanted =
      forced === null ? candidates : candidates.filter((c) => c.reader.ext === `.${forced}`);
    if (wanted.length === 0) {
      console.error(`--from ${forced}: no such file in this bundle`);
      process.exit(1);
    }
    wanted.sort(
      (a, b) =>
        a.reader.tier - b.reader.tier || READERS.indexOf(a.reader) - READERS.indexOf(b.reader),
    );
    const pick = wanted[0] as { file: string; reader: (typeof READERS)[number] };
    chosen = pick.file;
    const passed = found.filter((ext) => ext !== pick.reader.ext.slice(1));
    console.log(
      `Using ${path.relative(input, chosen)} — ${pick.reader.note} (tier ${pick.reader.tier})` +
        (passed.length === 0 ? '' : `. Passed over: ${passed.join(', ')}.`),
    );
  } else {
    chosen = input;
  }

  const imported =
    path.extname(chosen).toLowerCase() === '.blend'
      ? await loadBlend(
          chosen,
          args,
          outIndex === -1
            ? process.cwd()
            : path.dirname(path.resolve(args[outIndex + 1] as string)),
        )
      : await loadModel(chosen);
  /*
   * `--texture-codec jpeg`: opaque PNGs become JPEG, normal maps excepted; `jpeg-all` takes the normal
   * maps too. See `bakeTextureCap.ts` for what each gives up.
   */
  const codecIndex = args.indexOf('--texture-codec');
  const codecArg = codecIndex === -1 ? undefined : args[codecIndex + 1];
  if (codecArg !== undefined && codecArg !== 'jpeg' && codecArg !== 'jpeg-all') {
    console.error(`--texture-codec wants jpeg or jpeg-all, got "${codecArg}"`);
    process.exit(1);
  }
  const jpeg = codecArg === 'jpeg' ? 'opaque' : codecArg === 'jpeg-all' ? 'all' : undefined;
  /*
   * `--normals-directx`: the file's normal maps point green down, DirectX's way, where glTF points
   * it up, so each is turned over on the way in. Nothing in a file says which it wrote; the tell is
   * a horizontal joint whose rows above read green over the middle, which glTF would put under it.
   */
  const directxNormals = args.includes('--normals-directx');
  /*
   * `--decode-dds`: a block-compressed DDS is decoded and re-encoded as PNG rather than kept as its
   * blocks. For a consumer on a reader older than 1.24, which cannot read a BC texture; see
   * `bakeDds.ts` for what each gives up.
   */
  const decodeDds = args.includes('--decode-dds');
  const textured = (
    textures: DrftTextureSource[],
    materialList: readonly DrftMaterial[] | undefined,
    warnings: string[],
  ): Promise<DrftTextureSource[]> => {
    if (maxTexture === undefined && jpeg === undefined && !directxNormals) {
      return Promise.resolve(textures);
    }
    const normalMaps = new Set<number>();
    for (const material of materialList ?? [])
      if (material.normalMap >= 0) normalMaps.add(material.normalMap);
    return processTextures(
      textures,
      {
        ...(maxTexture === undefined ? {} : { maxSide: maxTexture }),
        ...(jpeg === undefined ? {} : { jpeg }),
        normalMaps,
        flipNormalGreen: directxNormals,
      },
      warnings,
    );
  };
  /* `MSHQ` rather than `MESH` unless declined: about a third of the geometry, within stated bounds. */
  const quantise = !args.includes('--no-quantise');
  const up = assetUp ?? imported.declaredUp ?? null;
  const siblings = readdirSync(path.dirname(chosen));

  /*
   * `--simplify m`: every mesh written brought down to the triangles its shape needs, the surface
   * moving no further than `m` and its textures no further than a texel of a 1,024 map. A bought
   * scene modelled for an offline renderer is mostly triangles smaller than a pixel. Absent writes
   * the bytes it always did.
   */
  const simplifyIndex = args.indexOf('--simplify');
  const simplifyError = simplifyIndex === -1 ? undefined : Number(args[simplifyIndex + 1]);
  if (simplifyIndex !== -1 && (simplifyError === undefined || !(simplifyError > 0))) {
    console.error(`--simplify wants a distance in metres, got "${args[simplifyIndex + 1] ?? ''}"`);
    process.exit(1);
  }
  /*
   * `--sdf m`: one distance field over the static geometry at `m` metres a voxel, for tracing
   * indirect light. Absent writes the bytes it always did.
   */
  const sdfIndex = args.indexOf('--sdf');
  const sdfVoxel = sdfIndex === -1 ? undefined : Number(args[sdfIndex + 1]);
  if (sdfIndex !== -1 && (sdfVoxel === undefined || !(sdfVoxel > 0))) {
    console.error(`--sdf wants a voxel size in metres, got "${args[sdfIndex + 1] ?? ''}"`);
    process.exit(1);
  }
  const colliderMode = colliderFlag(args);

  const options: BakeModelOptions = {
    name: path.basename(chosen, path.extname(chosen)),
    up: assetUp,
    ...(lodCells === undefined ? {} : { lodCells }),
    findInstances: !args.includes('--no-instances'),
    quantise,
    blendAsCutout: args.includes('--blend-as-cutout'),
    ...(simplifyError === undefined ? {} : { simplify: simplifyError }),
    ...(sdfVoxel === undefined ? {} : { sdf: sdfVoxel }),
  };
  const source = await bakeModel(imported, options, {
    log: (line) => console.log(line),
    warn: (line) => console.warn(line),
    textures: (refs, materials, warnings) =>
      textured(
        embedTextures(
          refs,
          chosen,
          stat.isDirectory() ? input : path.dirname(chosen),
          decodeDds,
          warnings,
        ),
        materials,
        warnings,
      ),
    levels: () => bakeLevels(chosen, siblings, args, up, quantise, decodeDds, textured),
    colliders: (meshes) => bakeColliders(colliderMode, chosen, siblings, meshes, up),
  });

  const output =
    outIndex === -1
      ? `${path.basename(chosen, path.extname(chosen))}.drft`
      : (args[outIndex + 1] as string);
  const buffer = writeDrft(source);
  writeFileSync(output, Buffer.from(buffer));

  const written = source.meshes as readonly MeshData[];
  const lights = source.lights;
  const vertices = written.reduce((sum, mesh) => sum + mesh.positions.length / 3, 0);
  const triangles = written.reduce((sum, mesh) => sum + mesh.indices.length / 3, 0);
  console.log(
    `${written.length} mesh${written.length === 1 ? '' : 'es'}, ${vertices} vertices, ` +
      `${triangles} triangles → ${output} (${(buffer.byteLength / 1024).toFixed(1)} KB)`,
  );
  if (lights !== undefined && lights.length > 0) {
    console.log(`  ${lights.length} light${lights.length === 1 ? '' : 's'} carried as LITE`);
  }
}

main().catch((error: unknown) => {
  /* A refusal is the designed outcome for a file that cannot be read, so it prints as one
     line rather than a stack — the message already names what was not understood. */
  console.error(error instanceof DrftError ? error.message : error);
  process.exit(1);
});
